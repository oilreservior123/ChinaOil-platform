# DFN / EDFM scientific demonstration assets

These files implement a small, actual numerical oil/water calculation. They are not a visual mock, a trained fracture predictor, or a calibrated field model.

## Files and browser API

- `physics-assets.json`: six actually solved cases, source/provenance, assumptions, three generated DFN proposals, and a controlled CRM benchmark.
- `physics-runtime-input.json`: public-reference graph geometry, mapped heterogeneous matrix permeability and documented assumed hydraulic parameters.
- `physics-runtime.mjs`: actual browser numerical solver, no dependencies.
- `generate_physics_assets.py`: independent NumPy/SciPy solver and scenario generator.
- `validate_runtime.mjs`: checks JavaScript cases against independent Python solutions and rejects invalid parameters.
- `validation_report.json`: fresh numerical test evidence.

```js
import { simulateEDFM } from './physics-runtime.mjs';
const graph = await fetch('./physics-runtime-input.json').then(r => r.json());
const result = await simulateEDFM(graph, {
  apertureMm: 0.5, pressureDropMPa: 5, durationDays: 180, timeSteps: 30
}, ({ progress, day, production }) => updateProgress(progress, day));
```

`result.snapshots[]` contains actual computed matrix pressure (MPa), water saturation (fraction 0–1), fracture pressure and fracture saturation. `production_curve[]` contains oil/water/liquid and injected-water volume rates in m³/day. The right pressure boundary is 25 MPa; the left is `25 + pressureDropMPa`. Pressure-driven injection varies in response to saturation and fracture aperture.

The browser implementation recomputes with PCG pressure solutions and fully implicit conservative upwind transport. Because each edge flux follows decreasing scalar pressure, the upwind graph is acyclic; solving a monotone scalar saturation root in pressure order is algebraically equivalent to solving the fixed-flux fully implicit transport system. The independent Python implementation uses a sparse direct pressure solve and coupled Newton transport.

## Scientific model and assumptions

- 12×10 matrix cells plus 276 fracture subsegments = 396 pressure/storage unknowns; 85 fracture-intersection couplings.
- Each source fracture is split at Cartesian cell crossings and each piece has its own pressure and pore volume; transfer to its host matrix cell, adjacent pieces and geometrical intersections is explicit.
- Matrix–fracture transfer uses contact area divided by approximated mean normal distance; fracture permeability follows the assumed parallel-plate cubic law `k_f = b²/12`.
- Incompressible immiscible oil and water, shared pressure, no gravity, capillarity, gas, thermal or mechanics solve. Pressure is updated sequentially at each step.
- Corey quadratic relative permeability, irreducible water saturation0.15, residual oil0.15, water viscosity1cP, oil viscosity3cP. Initial water saturation0.17.
- Public PorePy case4 line geometry is interpreted as a700×600m demonstration domain; these are not field map coordinates. Public SPE9 layer1 heterogeneity is mapped to this coarse grid and rescaled to median80mD.
- Matrix porosity0.2, thickness10m, aperture and boundary pressures are assumed scenario parameters, not calibrated measurements. Embedded fracture pore volume is added to retained matrix pore volume; fracture volume is negligible relative to matrix volume at these apertures.

## Train/validation/test examples

A physical simulator is not trained. For future surrogate-model or adapter demonstration, the six full simulation cases are split4/1/1 (66.7%/16.7%/16.7%).

| Split | Case IDs | Aperture / pressure drop |
|---|---|---|
| Train | EDFM-01…04 | 0.2 or0.5mm ×3 or5MPa |
| Validation | EDFM-05 | 1.0mm /3MPa |
| Test | EDFM-06 | 1.0mm /5MPa |

All share the same public geometry and matrix heterogeneity. This is a tiny parameter-case split, not independent geological generalization. No natural-fracture prediction accuracy is reported because there is no held-out field fracture truth.

## DFN proposals

`generated_dfn[]` contains three seeded stochastic proposals (assumed maximum-horizontal-stress azimuth0°,45°,90°). Sampling uses source orientation/length distributions and an explicitly assumed effective-normal-stress closure weighting. These are generated design scenarios, not inversion, coupled mechanics output or validated fracture predictions.

## CRM controlled benchmark

`crm_controlled_benchmark` is fully synthetic and separately marked. There are two independently stepped injector signals, one first-order production response, known weights0.65/0.25 and time constant12days, an independent declining contribution and noise. Split is252/54/54 observations (70/15/15), chronologically. The time constant is selected only on validation; test labels never select parameters. The high synthetic R² validates fitting on this controlled mechanism, not real-field connectivity. It must remain visually separate from the poor-generalizing real Volve baseline.

## Verification

```bash
python generate_physics_assets.py
node validate_runtime.mjs
```

Reported physical evaluation metrics are discrete pressure residual, oil/water transport conservation, saturation bounds and independent-implementation agreement. They are not prediction accuracy against a real reservoir.
