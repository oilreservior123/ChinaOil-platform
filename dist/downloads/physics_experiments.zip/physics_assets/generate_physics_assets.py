"""Actual compact 2D EDFM-style oil/water benchmark. Sources and assumptions are exported."""
from pathlib import Path
import json, math, re, time
import numpy as np, pandas as pd
from scipy.sparse import coo_matrix, diags, csr_matrix
from scipy.sparse.linalg import spsolve

ROOT=Path(__file__).resolve().parent
SRC=ROOT.parent/'recovered_data/reservoir_public_demo'
DAY=86400.; MD=9.869233e-16
NX,NY=12,10;LX,LY,H=700.,600.,10.;DX,DY=LX/NX,LY/NY;NM=NX*NY
SWC,SOR=.15,.15;SWMAX=1-SOR;MUW,MUO=.001,.003
public=pd.read_csv(SRC/'06_fractures/segments_2d.csv')
# Read published SPE9 heterogeneity, then map/rescale for the documented demonstration domain.
s=(SRC/'05_simulation/spe9/PERMVALUES.DATA').read_text();s='\n'.join(l.split('--')[0] for l in s.splitlines());vals=s.split('PERMX',1)[1].split('/')[0];rawk=np.array([float(t) for t in vals.split()]).reshape(15,25,24)
ix=np.minimum((np.arange(NX)+.5)*24/NX,23).astype(int);iy=np.minimum((np.arange(NY)+.5)*25/NY,24).astype(int)
kmd=rawk[0][np.ix_(iy,ix)];kmd=kmd/np.median(kmd)*80.;km=kmd.ravel()*MD
centers=np.array([[(i+.5)*DX,(j+.5)*DY] for j in range(NY) for i in range(NX)])
# Mesh each public line at grid crossings. Each subsegment has its own fracture pressure/storage DOF.
pieces=[];byfract={}
for fi,r in public.iterrows():
 a=np.array([r.x1,r.y1]);b=np.array([r.x2,r.y2]);delta=b-a;cuts=[0.,1.]
 for axis,spacing,count in [(0,DX,NX),(1,DY,NY)]:
  if abs(delta[axis])>1e-10:
   for n in range(1,count):
    t=(n*spacing-a[axis])/delta[axis]
    if 1e-8<t<1-1e-8:cuts.append(float(t))
 cuts=sorted(set(round(t,12) for t in cuts));ids=[]
 for ta,tb in zip(cuts[:-1],cuts[1:]):
  start=a+ta*delta;end=a+tb*delta;middle=(start+end)/2;length=float(np.linalg.norm(end-start))
  if length<1e-7:continue
  i=int(np.clip(middle[0]/DX,0,NX-1));j=int(np.clip(middle[1]/DY,0,NY-1));idx=len(pieces)
  pieces.append({'id':idx,'fracture_index':int(fi),'ta':ta,'tb':tb,'a':start,'b':end,'center':middle,'length':length,'matrix_cell':j*NX+i});ids.append(idx)
 byfract[int(fi)]=ids
NF=len(pieces);NN=NM+NF
# Determine geometrical fracture intersections independently of the computational grid.
intersections=[]
for f in range(len(public)):
 a=public.iloc[f][['x1','y1']].to_numpy(float);b=public.iloc[f][['x2','y2']].to_numpy(float);u=b-a
 for g in range(f):
  c=public.iloc[g][['x1','y1']].to_numpy(float);d=public.iloc[g][['x2','y2']].to_numpy(float);v=d-c;det=u[0]*v[1]-u[1]*v[0]
  if abs(det)<1e-8:continue
  ca=c-a;t=(ca[0]*v[1]-ca[1]*v[0])/det;w=(ca[0]*u[1]-ca[1]*u[0])/det
  if -.000001<=t<=1.000001 and -.000001<=w<=1.000001:
   pf=next((q for q in byfract[f] if pieces[q]['ta']-1e-7<=t<=pieces[q]['tb']+1e-7),None);pg=next((q for q in byfract[g] if pieces[q]['ta']-1e-7<=w<=pieces[q]['tb']+1e-7),None)
   if pf is not None and pg is not None:intersections.append((pf,pg))
left=np.array([j*NX for j in range(NY)]);right=np.array([j*NX+NX-1 for j in range(NY)]);bound=np.r_[left,right];free=np.array([n for n in range(NN) if n not in set(bound)])

def relperm(sw):
 se=np.clip((sw-SWC)/(1-SWC-SOR),0,1);kw=se*se;ko=(1-se)**2;lam=kw/MUW+ko/MUO;fw=(kw/MUW)/lam
 # analytic d(fw)/d(sw)
 num=2*se/MUW*lam-(kw/MUW)*(2*se/MUW-2*(1-se)/MUO)
 der=num/(lam*lam)/(1-SWC-SOR)
 return lam,fw,der

def geometry(aperture_mm):
 b=aperture_mm/1000.;kf=b*b/12.;edges=[]
 for j in range(NY):
  for i in range(NX):
   n=j*NX+i
   for jj,ii,area,dist in [(j,i+1,DY*H,DX),(j+1,i,DX*H,DY)]:
    if jj<NY and ii<NX:
     m=jj*NX+ii;k=2*km[n]*km[m]/(km[n]+km[m]);edges.append((n,m,k*area/dist,'matrix_matrix'))
 for q,p in enumerate(pieces):
  n=p['matrix_cell'];line=p['b']-p['a'];normal=np.array([-line[1],line[0]])/p['length'];distance=abs(float(np.dot(centers[n]-p['center'],normal)));distance=max(distance,.15*min(DX,DY))
  # EDFM-style shape factor: fracture contact area / average normal distance.
  trans=2*km[n]*p['length']*H/distance;edges.append((n,NM+q,trans,'matrix_fracture'))
 for ids in byfract.values():
  for q,r in zip(ids[:-1],ids[1:]):
   distance=.5*(pieces[q]['length']+pieces[r]['length']);edges.append((NM+q,NM+r,kf*b*H/distance,'fracture_fracture'))
 for q,r in intersections:
  distance=.5*(pieces[q]['length']+pieces[r]['length']);edges.append((NM+q,NM+r,kf*b*H/max(distance,1e-4),'fracture_intersection'))
 # Merge repeated undirected connections.
 ed={}
 for i,j,t,typ in edges:
  key=tuple(sorted((i,j)));ed[key]=ed.get(key,0)+t
 ea=np.array(list(ed));tt=np.array(list(ed.values()));pv=np.r_[np.full(NM,DX*DY*H*.2),np.array([p['length']*b*H for p in pieces])]
 return ea[:,0],ea[:,1],tt,pv,{'matrix_matrix':sum(t[3]=='matrix_matrix' for t in edges),'matrix_fracture':NF,'fracture_fracture':sum(t[3]=='fracture_fracture' for t in edges),'fracture_intersection':len(intersections)}

def pressure(sw,ei,ej,trans,drop_mpa):
 lam,_,_=relperm(sw);conduct=trans*(2*lam[ei]*lam[ej]/(lam[ei]+lam[ej]));diag=np.bincount(np.r_[ei,ej],weights=np.r_[conduct,conduct],minlength=NN)
 L=coo_matrix((np.r_[-conduct,-conduct],(np.r_[ei,ej],np.r_[ej,ei])),shape=(NN,NN)).tocsr()+diags(diag)
 p=np.zeros(NN);p[left]=(25+drop_mpa)*1e6;p[right]=25e6
 p[free]=spsolve(L[free][:,free],-L[free][:,bound]@p[bound]);flux=conduct*(p[ei]-p[ej]);source=np.asarray(L@p).ravel();qnorm=max(np.max(np.abs(flux)),1e-20)
 resid=np.max(np.abs(source[free]))/qnorm;source[free]=0
 return p,flux,source,resid

def implicit_transport(old,dt,pv,ei,ej,flux,source):
 up=np.where(flux>=0,ei,ej);down=np.where(flux>=0,ej,ei);q=np.abs(flux);inj=np.maximum(source,0);sink=np.maximum(-source,0)
 out=np.bincount(up,weights=q,minlength=NN)+sink;capacity=pv/dt
 def residual(s):
  _,fw,der=relperm(s);rin=capacity*(s-old)+out*fw-np.bincount(down,weights=q*fw[up],minlength=NN)-inj
  return rin,der
 s=old.copy();tol=max(float(inj.sum()),1e-10)*2e-9
 for it in range(65):
  r,der=residual(s);norm=float(np.max(np.abs(r)))
  if norm<tol:return s,it+1,norm
  J=diags(capacity+out*der)-coo_matrix((q*der[up],(down,up)),shape=(NN,NN)).tocsr()
  step=spsolve(J,-r);alpha=1.
  pos=step>0;neg=step<0
  if pos.any():alpha=min(alpha,float(np.min((SWMAX-s[pos]+1e-12)/step[pos]))*.995)
  if neg.any():alpha=min(alpha,float(np.min((SWC-s[neg]-1e-12)/step[neg]))*.995)
  alpha=max(min(alpha,1),1e-9)
  accepted=False
  for trial in range(18):
   candidate=np.clip(s+alpha*step,SWC,SWMAX);r2,_=residual(candidate)
   if np.max(np.abs(r2))<norm*(1-1e-5*alpha) or np.max(np.abs(r2))<tol:s=candidate;accepted=True;break
   alpha*=.5
  if not accepted:raise RuntimeError('Transport Newton line-search did not decrease residual')
 raise RuntimeError('Transport Newton exceeded iteration limit')

def simulate(case_id,bmm,drop,split):
 start=time.time();ei,ej,tr,pv,counts=geometry(bmm);s=np.full(NN,SWC+.02);initial=s.copy();t=0.;end=180*DAY;base_dt=6*DAY;next_save=0.;snapshots=[];curve=[];cinj=cprod=0.;max_pr=0;max_tr=0;max_iter=0;attempts=0
 def save(p):return {'day':round(t/DAY,4),'matrix_pressure_mpa':np.round(p[:NM].reshape(NY,NX)/1e6,6).tolist(),'matrix_water_saturation':np.round(s[:NM].reshape(NY,NX),6).tolist(),'fracture_pressure_mpa':np.round(p[NM:]/1e6,6).tolist(),'fracture_water_saturation':np.round(s[NM:],6).tolist()}
 p,flux,source,res=pressure(s,ei,ej,tr,drop);snapshots.append(save(p));next_save=30*DAY
 while t<end-.01:
  dt=min(base_dt,end-t,next_save-t if next_save>t+.01 else base_dt);p,flux,source,res=pressure(s,ei,ej,tr,drop);max_pr=max(max_pr,res)
  while True:
   try:new,its,resid=implicit_transport(s,dt,pv,ei,ej,flux,source);break
   except RuntimeError:
    dt*=.5;attempts+=1
    if dt<.001*DAY:raise
  s=new;t+=dt;max_tr=max(max_tr,resid);max_iter=max(max_iter,its);_,fw,_=relperm(s);qinj=np.maximum(source,0).sum();prod=np.maximum(-source,0);qwater=float(prod@fw);qoil=float(prod.sum()-qwater);cinj+=qinj*dt;cprod+=qwater*dt
  curve.append({'day':round(t/DAY,6),'oil_m3_day':round(qoil*DAY,6),'water_m3_day':round(qwater*DAY,6),'liquid_m3_day':round(float(prod.sum())*DAY,6),'injected_water_m3_day':round(qinj*DAY,6),'water_cut':round(qwater/max(prod.sum(),1e-20),6)})
  if t>=next_save-.01:
   p2,_,_,_=pressure(s,ei,ej,tr,drop);snapshots.append(save(p2));next_save+=30*DAY
 stored=float(pv@(s-initial));closure=stored-(cinj-cprod)
 metrics={'pressure_relative_residual_max':float(max_pr),'water_mass_balance_relative_error':abs(closure)/max(cinj,1.),'water_mass_balance_absolute_m3':closure,'cumulative_injected_water_m3':cinj,'cumulative_produced_water_m3':cprod,'domain_water_storage_change_m3':stored,'transport_residual_max_m3_s':float(max_tr),'transport_newton_iterations_max':max_iter,'accepted_time_steps':len(curve),'time_step_halvings':attempts,'runtime_seconds':round(time.time()-start,3),'minimum_saturation':float(s.min()),'maximum_saturation':float(s.max())}
 assert metrics['pressure_relative_residual_max']<1e-7,metrics
 assert metrics['water_mass_balance_relative_error']<1e-5,metrics
 assert s.min()>=SWC-1e-8 and s.max()<=SWMAX+1e-8
 return {'case_id':case_id,'split':split,'provenance':'numerically_solved_generated_scenario_on_public_geometry','parameters':{'reference_aperture_mm':bmm,'pressure_drop_mpa':drop,'production_boundary_pressure_mpa':25,'duration_days':180,'matrix_porosity':.2,'matrix_median_permeability_md':80,'water_viscosity_cp':1,'oil_viscosity_cp':3,'irreducible_water_saturation':SWC,'residual_oil_saturation':SOR},'metrics':metrics,'grid':{'nx':NX,'ny':NY,'width_m':LX,'height_m':LY,'thickness_m':H,'matrix_permeability_md':np.round(kmd,5).tolist()},'unknowns':{'matrix':NM,'fracture':NF,'total':NN,'coupling_counts':counts},'snapshots':snapshots,'production_curve':curve}


def synthetic_crm():
 from scipy.optimize import lsq_linear
 rng=np.random.default_rng(31);n=360;u=np.column_stack([np.repeat(rng.uniform(100,600,36),10),np.repeat(rng.uniform(100,500,36),10)]);tau=12.;f=np.array([.65,.25]);x=np.zeros_like(u)
 for t in range(1,n):x[t]=np.exp(-1/tau)*x[t-1]+(1-np.exp(-1/tau))*u[t-1]
 y=x@f+100*np.exp(-np.arange(n)/40)+rng.normal(0,2,n);a,b=252,306;best=None
 for tconst in [3,7,12,20,30,60]:
  z=np.zeros_like(u)
  for t in range(1,n):z[t]=np.exp(-1/tconst)*z[t-1]+(1-np.exp(-1/tconst))*u[t-1]
  design=np.column_stack([z,np.exp(-np.arange(n)/40)]);coef=lsq_linear(design[:a],y[:a],bounds=([0,0,0],[1,1,1000])).x;yp=design@coef;err=float(np.mean((yp[a:b]-y[a:b])**2))
  if best is None or err<best[0]:best=(err,tconst,coef,yp)
 _,tc,coef,yp=best;rmse=float(np.sqrt(np.mean((yp[b:]-y[b:])**2)));r2=1-float(np.sum((yp[b:]-y[b:])**2)/np.sum((y[b:]-y[b:].mean())**2))
 return {'model':'CRM simplified controlled response benchmark','provenance':'fully_generated_known_parameter_benchmark_not_field_data','scope':'two injector signals, one producer response, fixed response and independent declining contribution; not spatial field connectivity proof','split':{'train':a,'validation':b-a,'test':n-b,'ratio':[.70,.15,.15],'policy':'chronological'},'ground_truth':{'tau_days':tau,'weights':f.tolist()},'fit':{'tau_days':tc,'weights':coef[:2].tolist(),'initial_term':float(coef[2])},'metrics':{'test_RMSE_m3_day':rmse,'test_MAE_m3_day':float(np.mean(np.abs(yp[b:]-y[b:]))),'test_R2':r2,'weight_absolute_error':np.abs(coef[:2]-f).tolist()},'series':[{'day':i,'injector_1':round(u[i,0],4),'injector_2':round(u[i,1],4),'target':round(y[i],4),'prediction':round(yp[i],4),'split':'train' if i<a else 'validation' if i<b else 'test'} for i in range(n)]}


def stochastic_dfn():
 rng=np.random.default_rng(20261031);az=np.radians(public.azimuth_deg.to_numpy());length=public.length_model_unit.to_numpy();out=[]
 for stress_angle in [0,45,90]:
  # Construct a distribution conditioned on an explicit assumed normal-stress closure law.
  eff=30+10*np.sin(az-np.radians(stress_angle))**2-25;weights=np.exp(-eff/15);weights/=weights.sum();chosen=rng.choice(len(public),63,p=weights,replace=True);lines=[]
  for i,q in enumerate(chosen):
   theta=az[q]+rng.normal(0,.04);ln=float(length[q]*rng.uniform(.7,1.3));cx,cy=rng.uniform(0,LX),rng.uniform(0,LY);dx,dy=np.cos(theta)*ln/2,np.sin(theta)*ln/2
   lines.append({'id':f'DFN-GEN-{stress_angle}-{i}','x1':float(np.clip(cx-dx,0,LX)),'y1':float(np.clip(cy-dy,0,LY)),'x2':float(np.clip(cx+dx,0,LX)),'y2':float(np.clip(cy+dy,0,LY)),'sampled_reference_fracture_index':int(q)})
  out.append({'stress_direction_deg':stress_angle,'segments':lines,'provenance':'generated_orientation_distribution_conditioned_proposal_not_validated_fracture_prediction','assumed_geomechanics':{'sigma_H_mpa':40,'sigma_h_mpa':30,'pore_pressure_mpa':25,'closure_scale_mpa':15}})
 return out

if __name__=='__main__':
 cases=[]
 for i,(b,drop,sp) in enumerate([(.2,3,'train'),(.2,5,'train'),(.5,3,'train'),(.5,5,'train'),(1.,3,'validation'),(1.,5,'test')]):
  c=simulate(f'EDFM-{i+1:02d}',b,drop,sp);cases.append(c);print(c['case_id'],json.dumps(c['metrics']),flush=True)
 result={'schema_version':'1.0','models':[{'name':'DFN','implementation':'public-reference geometry plus explicitly generated stress-weighted orientation proposals','status':'geometry_import_and_generated_scenario','evaluation':'No field fracture truth; prediction accuracy unavailable.'},{'name':'EDFM two-phase compact reproduction','implementation':'2D incompressible oil/water; explicit matrix/fracture pressure unknowns; matrix-fracture transfer and along/intersection fracture transmissibility; sequential pressure + implicit conservative upwind Corey transport','status':'actually_solved_scientific_demonstration','evaluation':['pressure relative residual','water volume conservation','saturation bounds']}],'source':{'fracture_geometry':'PorePy public 2D benchmark case4, 63 segments','matrix_heterogeneity':'public SPE9 PERMX layer1 mapped to 12x10 and rescaled to scenario median80mD','public_data_root':'staging/recovered_data/reservoir_public_demo','original_coordinate_policy':'public model-coordinate extents are interpreted as700x600metres for this generated scenario; not georeferenced field coordinates'},'assumptions':['Two incompressible immiscible phases; no gas, gravity, capillarity, compressibility, thermal or mechanics solve.','Pressure-driven water injection on left and fixed-pressure withdrawal on right; all other external boundaries no-flow.','Each clipped public line piece is a distinct fracture pressure/storage DOF coupled to its host matrix cell.','Uniform assumed fracture aperture per case; cubic-law kf=b^2/12; no measured fracture hydraulic calibration.','Fracture intersections connected geometrically; matrix-fracture transfer uses a documented centroid-distance shape-factor approximation.','Matrix porosity0.2, thickness10m and fluid/relative-permeability parameters are scenario assumptions.','Sequential pressure/transport coupling is a simplified EDFM reproduction, not an industry-certified simulator.','Generated stress-weighted DFN proposals are not inversion or validated fracture predictions.'],'dataset_split':{'train_cases':4,'validation_cases':1,'test_cases':1,'ratio':[4/6,1/6,1/6],'unit':'entire simulation case','purpose':'examples for model adapters or future surrogate training; simulator itself is not trained','limitations':'Only six parameter combinations; all share public geometry/heterogeneity. Test is an aperture/pressure scenario, not independent geological generalization.'},'reference_geometry':public.to_dict(orient='records'),'fracture_pieces':[{'id':p['id'],'fracture_index':p['fracture_index'],'a':p['a'].tolist(),'b':p['b'].tolist(),'matrix_cell':p['matrix_cell']} for p in pieces],'cases':cases,'generated_dfn':stochastic_dfn(),'crm_controlled_benchmark':synthetic_crm()}
 (ROOT/'physics-assets.json').write_text(json.dumps(result,ensure_ascii=False,separators=(',',':'),allow_nan=False),encoding='utf-8');print('WROTE',ROOT/'physics-assets.json',flush=True)
